# Deploying the website to GitHub Pages

Pages for this repo is not served from a branch or a /docs folder — .github/workflows/pages.yml
builds app/ with Vite and publishes app/dist. Anything dropped at the repo root is never
deployed. The folder Vite copies through verbatim is app/public, so that is where these go.

## What to do

Copy the folder in this download into the repo, keeping the path:

    app/public/web/index.html
    app/public/web/app.html
    app/public/web/study.html

Commit to main. The existing workflow builds and deploys on push — nothing to configure, no
new workflow, no change to pages.yml.

## Where it lands

    https://harrisonjrubin7-cmyk.github.io/semester/web/          the front door
    https://harrisonjrubin7-cmyk.github.io/semester/web/app.html   the term
    https://harrisonjrubin7-cmyk.github.io/semester/web/study.html the study side

The phone app stays where it is, at /semester/. Same origin, so the website and the app share
the Supabase session and localStorage — sign in on one and the other already knows you.

## Notes

- Each file is self-contained (fonts, icons, design system, lesson data, Leaflet inlined), so
  they work offline and can be moved as a set. Keep the three side by side; they link to each
  other by filename.
- ~3 MB total, against ~200 MB of audio already in the deploy — no size concern.
- The workflow's 404.html fallback is unaffected: these are real files at real paths.
